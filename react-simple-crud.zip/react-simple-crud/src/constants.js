export const CATEGORIES = ["General", "Work", "Personal"];
