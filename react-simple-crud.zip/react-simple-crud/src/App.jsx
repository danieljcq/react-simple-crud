import React, { useState, useEffect } from "react";
import './App.css';
import AddItemForm from "./components/AddItemForm";
import ItemList from "./components/ItemList";
import SearchBar from "./components/SearchBar";
import { CATEGORIES } from "./constants";

const App = () => {
    const [items, setItems] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [filterCategory, setFilterCategory] = useState("All");

    useEffect(() => {
        const savedItems = localStorage.getItem("items");
        if (savedItems) {
            setItems(JSON.parse(savedItems));
        }
    }, []);

    useEffect(() => {
        localStorage.setItem("items", JSON.stringify(items));
    }, [items]);

    const addItem = (name, category) => {
        const newItem = { id: Date.now(), name, category, completed: false };
        setItems([...items, newItem]);
    };

    const updateItem = (id) => {
        const updatedName = prompt("Enter the new name:");
        if (updatedName && updatedName.trim() !== "") {
            const updatedItems = items.map((item) =>
                item.id === id ? { ...item, name: updatedName } : item
            );
            setItems(updatedItems);
        } else {
            alert("Item name cannot be empty.");
        }
    };

    const deleteItem = (id) => {
        if (window.confirm("Are you sure you want to delete this item?")) {
            const updatedItems = items.filter((item) => item.id !== id);
            setItems(updatedItems);
        }
    };

    const completeItem = (id) => {
        const updatedItems = items.map((item) =>
            item.id === id ? { ...item, completed: !item.completed } : item
        );
        setItems(updatedItems);
    };

    const filteredItems = items.filter((item) =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
        (filterCategory === "All" || item.category === filterCategory)
    );

    return (
        <div className="App">
            <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
            <div className="category-filter">
                <span>Filter by category:</span>
                <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)}>
                    <option value="All">All</option>
                    {CATEGORIES.map((category) => (
                        <option key={category} value={category}>{category}</option>
                    ))}
                </select>
            </div>
            <AddItemForm onAdd={addItem} />
            <ItemList items={filteredItems} onEdit={updateItem} onDelete={deleteItem} onComplete={completeItem} />
        </div>
    );
};

export default App;
