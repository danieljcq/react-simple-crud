import React from "react";

const ItemList = ({ items, onEdit, onDelete, onComplete }) => (
    <div>
        {items.length === 0 ? (
            <p>No tasks registered</p>
        ) : (
            items.map((item) => (
                <div key={item.id} className="item">
                    <span style={{ textDecoration: item.completed ? "line-through" : "none" }}>
                        {item.name}
                    </span>
                    <button onClick={() => onComplete(item.id)}>
                        {item.completed ? "Undo" : "Complete"}
                    </button>
                    <button onClick={() => onEdit(item.id)}>Edit</button>
                    <button onClick={() => onDelete(item.id)}>Delete</button>
                </div>
            ))
        )}
    </div>
);

export default ItemList;
