import React, { useState } from "react";
import { CATEGORIES } from "../constants";

const AddItemForm = ({ onAdd }) => {
    const [itemName, setItemName] = useState("");
    const [category, setCategory] = useState("General");

    const handleSubmit = (e) => {
        e.preventDefault();

        if (itemName.trim() !== "") {
            onAdd(itemName, category);
            setItemName("");
            setCategory("General");
        } else {
            alert("Item name cannot be empty.");
        }
    };

    return (
        <form onSubmit={handleSubmit} className="add-item-form">
            <input
                type="text"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                placeholder="Enter item name"
            />
            <select value={category} onChange={(e) => setCategory(e.target.value)}>
                {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                ))}
            </select>
            <button type="submit">Add Task</button>
        </form>
    );
};

export default AddItemForm;
